/*
 * Add the include files that you need. "man" can help you find them.
 * You will probably need stdio.h for printf and fprintf
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "apple-todo.h"

/*
 * Find the requirements for these functions in the assignment text.
 */
int locateworm( char* buffer )
{
    printf( "This function does nothing yet.\n" );
    return 0;
}

int removeworm( char* apple )
{
    printf( "This function does nothing yet.\n" );
    return 0;
}

