#!/bin/bash
pandoc -o LOGIN-en.html LOGIN-en.md
pandoc -o LOGIN-no.html LOGIN-no.md
pandoc -o README-en.html README-en.md
pandoc -o README.html README.md
