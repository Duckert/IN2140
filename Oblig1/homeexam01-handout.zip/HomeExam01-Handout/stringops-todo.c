/*
 * Add the include files that you need. "man" can help you find them.
 * You will probably need stdio.h for printf and fprintf
 */
#include <stdio.h>

#include "stringops-todo.h"

/*
 * Find the requirements for these functions in the assignment text.
 */
int   stringsum( char *s )
{
    printf( "%s does nothing yet\n", __FUNCTION__ );
    return 0;
}

int   distance_between( char *s, char c )
{
    printf( "%s does nothing yet\n", __FUNCTION__ );
    return 0;
}

char* string_between( char *s, char c )
{
    printf( "%s does nothing yet\n", __FUNCTION__ );
    return NULL;
}

int  stringsum2( char *s, int *res )
{
    printf( "%s does nothing yet\n", __FUNCTION__ );
    return 0;
}


