#ifndef STRINGSOPS_H
#define STRINGSOPS_H

int   stringsum( char *s );
int   distance_between( char *s, char c );
char* string_between( char *s, char c );
int   stringsum2( char *s, int *res );

#endif

